# ATLAS Academia — proyecto Android de demostración

Este es un proyecto fuente para abrir/compilar con Android Studio o un servicio de compilación compatible. **No es un APK ya compilado.**

## Incluye
- Interfaz web de demostración incluida en `app/src/main/assets/index.html`.
- Actividad Android con WebView y almacenamiento local del navegador.

## Limitaciones importantes
- No incluye autenticación real ni base de datos en la nube.
- No procesa pagos ni incluye IA conectada.
- Los datos locales no se sincronizan entre dispositivos. El modo de edición de la demo no es seguridad real.
- Requiere Android SDK 35 y JDK compatible para compilar con Android Gradle Plugin 8.7.3.
